{{-- form input --}}
<div class="row justify-content-center d-md-flex h-100" style="padding: 5%">
    <hr>
    <div style="padding: 2%">

        <div class="mb-3"><label for="exampleColorInput" class="form-label">Warna Primer</label>
            <div style="padding: 2%">
                <input type="color" class="form-control form-control-color" id="exampleColorInput" value="#563d7c"
                    title="Choose your color">
            </div>
        </div>

        <div class="mb-3"><label for="exampleColorInput" class="form-label">Warna Pertama</label>
            <div style="padding: 2%">
                <input type="color" class="form-control form-control-color" id="exampleColorInput" value="#563d7c"
                    title="Choose your color">
            </div>
        </div>

        <div class="mb-3"><label for="exampleColorInput" class="form-label">Warna Kedua</label>
            <div style="padding: 2%">
                <input type="color" class="form-control form-control-color" id="exampleColorInput" value="#563d7c"
                    title="Choose your color">
            </div>
        </div>

        <div class="mb-3" style="padding: 2%">
            <button type="button" class="btn btn-secondary">Simpan Settings</button>
        </div>
    </div>
    <hr>
</div>
