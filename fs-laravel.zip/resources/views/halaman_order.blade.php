{{-- form input --}}
<div class="row justify-content-center d-md-flex h-100" style="padding: 5%">
    <hr>
    <div style="padding: 2%">
        {{-- <div class="mb-3" style="padding-bottom: 1%">
            <h4>Setting - Halaman Order</h4>
        </div> --}}

        <div class="mb-3">
            <label for="formFile" class="form-label">Header Image</label>
            <input class="form-control" type="file" id="formFile">
        </div>

        <div class="mb-3">
            <label for="formFile" class="form-label">Background Image</label>
            <input class="form-control" type="file" id="formFile">
        </div>

        <div class="mb-3" style="padding: 2%">
            <button type="button" class="btn btn-secondary">Simpan Settings</button>
        </div>
    </div>
    <hr>
</div>
